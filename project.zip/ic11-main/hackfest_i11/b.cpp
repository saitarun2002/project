
int main() {
  int result = sum(10);
  cout << result;
  return 0;
}


int multi(){
  for(int i=0;i>5;i++){
     int res =  sum(4);
  }

  return 0;

}


