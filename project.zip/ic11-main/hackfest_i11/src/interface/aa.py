from inp import index
